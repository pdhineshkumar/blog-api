package com.test.task.blogapi.model;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class BlogTest {

    private Blog blog;

    @BeforeEach
    void setUp() {
         blog =new Blog("UnitTestId","dhineshkumar.pach","How To Create Reactive API?", "This blog going to describe step by step instructions how reactive..",new Timestamp(new Date().getTime()),
                new ArrayList<>(),new Timestamp(new Date().getTime()));
    }

    @AfterEach
    void tearDown() {
        blog=null;
    }

    @Test
    void getId() {
        assertNotNull(blog.getId());
        assertEquals(blog.getId(),"UnitTestId");
    }

    @Test
    void setId() {
        blog.setId("UpdatedId");
        assertNotNull(blog.getId());
        assertEquals(blog.getId(),"UpdatedId");
    }

    @Test
    void getNickName() {
        assertNotNull(blog.getNickName());
        assertEquals(blog.getNickName(),"dhineshkumar.pach");
    }

    @Test
    void setNickName() {
        blog.setNickName("UpdatedAuthorId");
        assertNotNull(blog.getNickName());
        assertEquals(blog.getNickName(),"UpdatedAuthorId");
    }

    @Test
    void getTitle() {
        assertNotNull(blog.getTitle());
        assertEquals(blog.getTitle(),"How To Create Reactive API?");
    }

    @Test
    void setTitle() {
        blog.setTitle("UpdatedTitle");
        assertNotNull(blog.getTitle());
        assertEquals(blog.getTitle(),"UpdatedTitle");
    }

    @Test
    void getContent() {
        assertNotNull(blog.getContent());
        assertEquals(blog.getContent(),"This blog going to describe step by step instructions how reactive..");
    }

    @Test
    void setContent() {
        blog.setContent("UpdatedContent..");
        assertNotNull(blog.getContent());
        assertEquals(blog.getContent(),"UpdatedContent..");
    }

    @Test
    void getPublishDate() {
        assertNotNull(blog.getPublishDate());
    }

    @Test
    void setPublishDate() {
        blog.setPublishDate(new Timestamp(new Date().getTime()));
        assertNotNull(blog.getPublishDate());
    }

    @Test
    void getComments() {
        assertNotNull(blog.getComments());
        assertEquals(0,blog.getComments().size());
    }

    @Test
    void setComments() {
        List<String> comments= blog.getComments();
        comments.add("This blog is awesome, appreciate your information's!");
        blog.setComments(comments);
        assertNotNull(blog.getComments());
        assertEquals(1,blog.getComments().size());
    }

    @Test
    void getUpdatedTimeStamp() {
        assertNotNull(blog.getUpdatedTimeStamp());
    }

    @Test
    void setUpdatedTimeStamp() {
        blog.setUpdatedTimeStamp(new Timestamp(new Date().getTime()));
        assertNotNull(blog.getUpdatedTimeStamp());
    }
}