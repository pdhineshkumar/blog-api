package com.test.task.blogapi.service.impl;

import com.test.task.blogapi.model.Blog;
import com.test.task.blogapi.repository.BlogRepository;
import com.test.task.blogapi.service.BlogsService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.mock.mockito.MockBean;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
class BlogServiceImplTest {

    Blog blog;

    @Mock
    BlogsService blogsService;

    @BeforeEach
    void setUp() {
        blog =new Blog("UnitTestId","dhineshkumar.pach","How To Create Reactive API?", "This blog going to describe step by step instructions how reactive..",new Timestamp(new Date().getTime()),
                new ArrayList<>(),new Timestamp(new Date().getTime()));

        MockitoAnnotations.initMocks(this);
    }

    @AfterEach
    void tearDown() {
        blog=null;
    }

    @Test
    void saveBlog() {
        //doNothing().when(blogsService.saveBlog(any()));
        blog.setId(null);
        blogsService.saveBlog(blog);
    }

    @Test
    void updateBlog() {
        Mono<Blog> monoBlog = Mono.just(blog);
        when(blogsService.updateBlog(blog)).thenReturn(monoBlog);
        assertNotNull(blogsService.updateBlog(blog));
    }

    @Test
    void findByAuthorOrderByCreatedTimeStamp() {
        String authorNickName="dhineshkumar.pacha";
        List<Blog> blogArrayList = new ArrayList<>();
        blogArrayList.add(blog);
        Flux<List<Blog>> blogs = Flux.just(blogArrayList);
        when(blogsService.findByAuthorOrderByCreatedTimeStamp(authorNickName)).thenReturn(blogs);

        Flux<List<Blog>> blogsByAuthor = blogsService.findByAuthorOrderByCreatedTimeStamp(authorNickName);
        assertNotNull(blogsByAuthor);
    }
}