package com.test.task.blogapi.controller;

import com.test.task.blogapi.model.Blog;
import com.test.task.blogapi.service.BlogsService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.BodyInserters;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

@RunWith(SpringRunner.class)
@ExtendWith(SpringExtension.class)
@WebFluxTest(controllers = BlogController.class)
@Import(BlogsService.class)
class BlogControllerTest {

    @Autowired
    private WebTestClient webClient;

    @Autowired
    private BlogController controller;

    @MockBean
    private BlogsService blogsService;

    private Blog blog;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        blog =new Blog("UnitTestId","dhineshkumar.pach","How To Create Reactive API?", "This blog going to describe step by step instructions how reactive..",new Timestamp(new Date().getTime()),
                new ArrayList<>(),new Timestamp(new Date().getTime()));
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void blogsByAuthorName() {

        webClient.get()
                .uri("/blogs?authorNickName=dhineshkumar.pacha")
                .exchange()
                .expectStatus().isNotFound();

    }

    @Test
    void saveBlog(){

        webClient.post()
                .uri("/blog")
                .contentType(MediaType.APPLICATION_JSON)
                .body(BodyInserters.fromValue(blog))
                .exchange()
                .expectStatus().isNotFound();
    }

    @Test
    void updateBlog(){

        webClient.put()
                .uri("/blog")
                .contentType(MediaType.APPLICATION_JSON)
                .body(BodyInserters.fromValue(blog))
                .exchange()
                .expectStatus().isNotFound();
    }
}