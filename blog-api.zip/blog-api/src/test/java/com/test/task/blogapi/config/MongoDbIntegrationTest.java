package com.test.task.blogapi.config;

import com.test.task.blogapi.model.Blog;
import com.test.task.blogapi.repository.BlogRepository;
import com.test.task.blogapi.service.BlogsService;
import de.flapdoodle.embed.mongo.MongodExecutable;
import de.flapdoodle.embed.mongo.MongodStarter;
import de.flapdoodle.embed.mongo.config.IMongodConfig;
import de.flapdoodle.embed.mongo.config.MongodConfigBuilder;
import de.flapdoodle.embed.mongo.config.Net;
import de.flapdoodle.embed.mongo.distribution.Version;
import de.flapdoodle.embed.process.runtime.Network;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

/*
* For Integration Test, Mongo DB host information will be supplied from test application.yml
* Yet to do, other database interactions as a test cases
*/

public class MongoDbIntegrationTest {

    @Value("${spring.data.mongodb.database}")
    private String dbName;

    @Value("${spring.data.mongodb.host}")
    private String host;

    @Value("${spring.data.mongodb.port}")
    private int dbPort;

    private MongodExecutable mongodExecutable;

    @Autowired
    private BlogRepository blogRepository;

    @AfterEach
    void clean() {
        mongodExecutable.stop();
    }

    @BeforeEach
    void setup() throws Exception {
        String ip = host;
        int port = dbPort;

        IMongodConfig mongodConfig = new MongodConfigBuilder().version(Version.Main.PRODUCTION)
                .net(new Net(ip, port, Network.localhostIsIPv6()))
                .build();

        MongodStarter starter = MongodStarter.getDefaultInstance();
        mongodExecutable = starter.prepare(mongodConfig);
        mongodExecutable.start();
    }

    @Test
    public void saveBlogtest() throws Exception {
        Blog blog =new Blog(null,"dhineshkumar.pach","How To Create Reactive API?", "This blog going to describe step by step instructions how reactive..",new Timestamp(new Date().getTime()),
                new ArrayList<>(),new Timestamp(new Date().getTime()));
        //blogRepository.save(blog);
    }
}
