package com.test.task.blogapi.service.impl;

import com.test.task.blogapi.model.Blog;
import com.test.task.blogapi.repository.BlogRepository;
import com.test.task.blogapi.service.BlogsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class BlogServiceImpl implements BlogsService {

    @Autowired
    private BlogRepository blogRepository;

    @Override
    public void saveBlog(Blog blog){
        blogRepository.save(blog).subscribe();
    }

    @Override
    public Mono<Blog> updateBlog(Blog blog){
        return blogRepository.save(blog);
    }

    @Override
    public Flux<List<Blog>> findByAuthorOrderByCreatedTimeStamp(String nickName){
      return   blogRepository.findByAuthorOrderByPublishDateDesc(nickName);
    }


}
