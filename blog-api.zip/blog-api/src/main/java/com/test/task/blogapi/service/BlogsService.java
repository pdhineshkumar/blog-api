package com.test.task.blogapi.service;

import com.test.task.blogapi.model.Blog;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

public interface BlogsService {
    void saveBlog(Blog blog);
    Mono<Blog> updateBlog(Blog blog);
    Flux<List<Blog>> findByAuthorOrderByCreatedTimeStamp(String nickName);
}
