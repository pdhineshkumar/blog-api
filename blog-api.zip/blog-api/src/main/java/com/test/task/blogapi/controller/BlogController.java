package com.test.task.blogapi.controller;

import com.test.task.blogapi.model.Blog;
import com.test.task.blogapi.service.BlogsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

@RestController
@RequestMapping("/api")
public class BlogController {

    @Autowired
    BlogsService blogsService;

    @GetMapping(value = "/blogs")
    @ResponseStatus(HttpStatus.OK)
    public Flux<List<Blog>> blogsByAuthorName(@PathVariable("authorNickName") String authorNickName) {
        return blogsService.findByAuthorOrderByCreatedTimeStamp(authorNickName);
    }


    @PostMapping(value = "/blog")
    @ResponseStatus(HttpStatus.CREATED)
    public void saveOrUpdateBlog(@RequestBody Blog blog){
         blogsService.saveBlog(blog);
    }

    @PutMapping(value = "/blog")
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<Blog> updateBlog(@RequestBody Blog blog){
        return blogsService.updateBlog(blog);
    }


}
