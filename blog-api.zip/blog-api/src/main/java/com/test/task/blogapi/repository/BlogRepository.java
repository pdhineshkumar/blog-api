package com.test.task.blogapi.repository;

import com.test.task.blogapi.model.Blog;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;

import java.util.List;

public interface BlogRepository extends ReactiveMongoRepository<Blog, String> {

    @Query("find({ 'nickName': ?0 }).sort({publishDate:-1})")
    Flux<List<Blog>> findByAuthorOrderByPublishDateDesc(String nickName);

}