package com.test.task.blogapi.model;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.IndexDirection;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.index.TextIndexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.sql.Timestamp;
import java.util.List;
import java.util.Objects;

/*
* lombok can be used to reduce number of code writing for getter, setter, construct ,tostring etc.
*/

@Document(collection = "Blogs")
public class Blog {


    @Id
    private String id;
    @TextIndexed
    private String nickName;
    private String title;
    private String content;
    @Indexed(direction = IndexDirection.DESCENDING)
    @CreatedDate
    private Timestamp publishDate;
    private List<String> comments;
    @LastModifiedDate
    private Timestamp updatedTimeStamp;

    public Blog() {
    }

    public Blog(String id, String nickName, String title, String content, Timestamp publishDate, List<String> comments, Timestamp updatedTimeStamp) {
        this.id = id;
        this.nickName = nickName;
        this.title = title;
        this.content = content;
        this.publishDate = publishDate;
        this.comments = comments;
        this.updatedTimeStamp = updatedTimeStamp;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Timestamp getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(Timestamp publishDate) {
        this.publishDate = publishDate;
    }

    public List<String> getComments() {
        return comments;
    }

    public void setComments(List<String> comments) {
        this.comments = comments;
    }

    public Timestamp getUpdatedTimeStamp() {
        return updatedTimeStamp;
    }

    public void setUpdatedTimeStamp(Timestamp updatedTimeStamp) {
        this.updatedTimeStamp = updatedTimeStamp;
    }


    @Override
    public String toString() {
        return "{" +
                "id='" + id + '\'' +
                ", nickName='" + nickName + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", publishDate=" + publishDate +
                ", comments=" + comments +
                ", updatedTimeStamp=" + updatedTimeStamp +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Blog)) return false;
        Blog blog = (Blog) o;
        return Objects.equals(getId(), blog.getId()) &&
                Objects.equals(getNickName(), blog.getNickName()) &&
                Objects.equals(getTitle(), blog.getTitle()) &&
                Objects.equals(getContent(), blog.getContent()) &&
                Objects.equals(getPublishDate(), blog.getPublishDate()) &&
                Objects.equals(getComments(), blog.getComments()) &&
                Objects.equals(getUpdatedTimeStamp(), blog.getUpdatedTimeStamp());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getNickName(), getTitle(), getContent(), getPublishDate(), getComments(), getUpdatedTimeStamp());
    }
}
